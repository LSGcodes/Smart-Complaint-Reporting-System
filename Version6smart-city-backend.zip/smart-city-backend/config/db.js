const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  host:     process.env.DB_HOST,
  port:     process.env.DB_PORT,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  max: 10,
  idleTimeoutMillis: 30000,
});

pool.connect()
  .then(client => {
    console.log('✅  PostgreSQL connected — Local');
    client.release();
  })
  .catch(err => {
    console.error('❌  PostgreSQL failed:', err.message);
    process.exit(1);
  });

module.exports = pool;