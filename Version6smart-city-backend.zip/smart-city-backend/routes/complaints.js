const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const router  = express.Router();

// ─── File upload setup ───────────────────────────────────────────
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename:    (req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s/g,'_')}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    if (allowed.test(path.extname(file.originalname).toLowerCase())) cb(null, true);
    else cb(new Error('Only image files allowed'));
  },
});

// ─── Helper: generate ref_id ─────────────────────────────────────
const genRefId = async () => {
  const { rows } = await db.query('SELECT COUNT(*) AS cnt FROM complaints');
  const num = parseInt(rows[0].cnt) + 1;
  return `CMP-${String(num).padStart(3, '0')}`;
};

// ─────────────────────────────────────────────────────────────────
// GET /api/complaints
// ─────────────────────────────────────────────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    const { status, category, priority } = req.query;

    let sql  = `SELECT c.id, c.ref_id, c.citizen_id, c.category, c.description,
                       c.address, c.latitude, c.longitude, c.photo_url,
                       c.status, c.priority, c.ai_category, c.ai_priority,
                       c.admin_overridden, c.council_review_requested,
                       c.rating, c.rating_comment, c.created_at,
                       u.full_name AS citizen_name, u.email AS citizen_email
                FROM complaints c
                JOIN users u ON c.citizen_id = u.id
                WHERE 1=1`;
    const vals = [];
    let idx = 1;

    if (req.user.role === 'Citizen') {
      sql += ` AND c.citizen_id = $${idx++}`;
      vals.push(req.user.id);
    }

    if (status)   { sql += ` AND c.status = $${idx++}`;   vals.push(status); }
    if (category) { sql += ` AND c.category = $${idx++}`; vals.push(category); }
    if (priority) { sql += ` AND c.priority = $${idx++}`; vals.push(priority); }

    sql += ' ORDER BY c.created_at DESC';

    const { rows } = await db.query(sql, vals);

    res.json({ success: true, count: rows.length, complaints: rows });
  } catch (err) {
    console.error('GET /complaints error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch complaints', error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────
// GET /api/complaints/:id
// ─────────────────────────────────────────────────────────────────
router.get('/:id', protect, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT c.*, u.full_name AS citizen_name, u.email AS citizen_email
       FROM complaints c JOIN users u ON c.citizen_id = u.id
       WHERE c.id = $1`,
      [req.params.id]
    );
    if (rows.length === 0)
      return res.status(404).json({ success: false, message: 'Complaint not found' });

    const { rows: history } = await db.query(
      `SELECT sh.*, u.full_name AS changed_by_name
       FROM status_history sh JOIN users u ON sh.changed_by = u.id
       WHERE sh.complaint_id = $1 ORDER BY sh.changed_at ASC`,
      [req.params.id]
    );

    res.json({ success: true, complaint: rows[0], history });
  } catch (err) {
    console.error('GET /complaints/:id error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch complaint' });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/complaints — submit new complaint (Citizen only)
// ─────────────────────────────────────────────────────────────────
router.post('/', protect, restrictTo('Citizen'), upload.single('photo'), async (req, res) => {
  try {
    console.log('📥 New complaint from user:', req.user.id, req.user.email);
    console.log('📥 Body:', req.body);
    console.log('📥 File:', req.file?.filename);

    const { category, description, address, latitude, longitude } = req.body;

    if (!category || !description) {
      return res.status(400).json({ success: false, message: 'Category and description are required' });
    }

    const ref_id    = await genRefId();
    const photo_url = req.file ? `/uploads/${req.file.filename}` : null;
    const lat       = parseFloat(latitude)  || null;
    const lng       = parseFloat(longitude) || null;

    const { rows: inserted } = await db.query(
      `INSERT INTO complaints
         (ref_id, citizen_id, category, description, address, latitude, longitude, photo_url, status, priority)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'Submitted', 'Medium')
       RETURNING id`,
      [ref_id, req.user.id, category, description, address || null, lat, lng, photo_url]
    );

    const complaintId = inserted[0].id;
    console.log('✅ Complaint inserted with ID:', complaintId, 'ref_id:', ref_id);

    // Log initial status history
    await db.query(
      `INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes)
       VALUES ($1, $2, NULL, 'Submitted', 'Complaint submitted by citizen')`,
      [complaintId, req.user.id]
    );

    // Notify citizen
    await db.query(
      `INSERT INTO notifications (user_id, complaint_id, type, subject, message)
       VALUES ($1, $2, 'in_app', 'Complaint Submitted', $3)`,
      [req.user.id, complaintId, `Your complaint ${ref_id} has been submitted and is being processed.`]
    );

    res.status(201).json({
      success:      true,
      message:      'Complaint submitted successfully',
      ref_id:       ref_id,
      complaint_id: complaintId,
    });
  } catch (err) {
    console.error('POST /complaints error:', err);
    res.status(500).json({ success: false, message: 'Failed to submit complaint', error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────
// PATCH /api/complaints/:id/status
// ─────────────────────────────────────────────────────────────────
router.patch('/:id/status', protect, restrictTo('Technician', 'Administrator'), async (req, res) => {
  try {
    const { status, notes } = req.body;
    const validStatuses = ['Submitted','Classified','Assigned','In Progress','Resolved'];
    if (!validStatuses.includes(status))
      return res.status(400).json({ success: false, message: 'Invalid status' });

    const { rows } = await db.query(
      'SELECT status, citizen_id FROM complaints WHERE id = $1',
      [req.params.id]
    );
    if (rows.length === 0)
      return res.status(404).json({ success: false, message: 'Complaint not found' });

    const old_status = rows[0].status;
    const citizen_id = rows[0].citizen_id;

    await db.query('UPDATE complaints SET status = $1 WHERE id = $2', [status, req.params.id]);

    await db.query(
      `INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes)
       VALUES ($1, $2, $3, $4, $5)`,
      [req.params.id, req.user.id, old_status, status, notes || null]
    );

    await db.query(
      `INSERT INTO notifications (user_id, complaint_id, type, subject, message)
       VALUES ($1, $2, 'in_app', 'Complaint Update', $3)`,
      [citizen_id, req.params.id, `Your complaint status has been updated to: ${status}${status==='Resolved'?'. Please rate the service.':''}`]
    );

    res.json({ success: true, message: `Status updated to ${status}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to update status' });
  }
});

// ─────────────────────────────────────────────────────────────────
// PATCH /api/complaints/:id/classify
// ─────────────────────────────────────────────────────────────────
router.patch('/:id/classify', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { category, priority, ai_category, ai_priority, confidence, admin_override } = req.body;

    await db.query(
      `UPDATE complaints SET category = $1, priority = $2, ai_category = $3, ai_priority = $4,
       admin_overridden = $5, status = 'Classified' WHERE id = $6`,
      [category, priority, ai_category || category, ai_priority || priority, admin_override ? true : false, req.params.id]
    );

    if (confidence) {
      await db.query(
        `INSERT INTO ai_logs (complaint_id, predicted_cat, predicted_pri, confidence, model_version)
         VALUES ($1, $2, $3, $4, 'nlp-v1.0')`,
        [req.params.id, ai_category, ai_priority, confidence]
      );
    }

    const { rows } = await db.query(
      'SELECT status, citizen_id FROM complaints WHERE id = $1',
      [req.params.id]
    );
    if (rows.length > 0) {
      await db.query(
        `INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes)
         VALUES ($1, $2, $3, 'Classified', $4)`,
        [req.params.id, req.user.id, rows[0].status, `AI classified as ${ai_category}/${ai_priority}`]
      );
    }

    res.json({ success: true, message: 'Complaint classified successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to classify complaint' });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/complaints/:id/rate
// ─────────────────────────────────────────────────────────────────
router.post('/:id/rate', protect, restrictTo('Citizen'), async (req, res) => {
  try {
    const { rating, comment } = req.body;
    if (!rating || rating < 1 || rating > 5)
      return res.status(400).json({ success: false, message: 'Rating must be 1–5' });

    await db.query(
      'UPDATE complaints SET rating = $1, rating_comment = $2 WHERE id = $3 AND citizen_id = $4',
      [rating, comment || null, req.params.id, req.user.id]
    );

    res.json({ success: true, message: 'Rating submitted! Thank you.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to submit rating' });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/complaints/:id/request-review
// ─────────────────────────────────────────────────────────────────
router.post('/:id/request-review', protect, restrictTo('Citizen'), async (req, res) => {
  try {
    await db.query(
      'UPDATE complaints SET council_review_requested = TRUE WHERE id = $1 AND citizen_id = $2',
      [req.params.id, req.user.id]
    );

    const { rows: councillors } = await db.query(
      "SELECT id FROM users WHERE role = 'Councillor' LIMIT 1"
    );
    if (councillors.length > 0) {
      await db.query(
        `INSERT INTO escalations (complaint_id, councillor_id, escalated_by, escalation_type)
         VALUES ($1, $2, $3, 'citizen_request')`,
        [req.params.id, councillors[0].id, req.user.id]
      );

      await db.query(
        `INSERT INTO notifications (user_id, complaint_id, type, subject, message)
         VALUES ($1, $2, 'in_app', 'Council Review Requested', $3)`,
        [councillors[0].id, req.params.id, `A citizen has requested council review for complaint ID ${req.params.id}.`]
      );
    }

    res.json({ success: true, message: 'Council review requested successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to request review' });
  }
});

module.exports = router;