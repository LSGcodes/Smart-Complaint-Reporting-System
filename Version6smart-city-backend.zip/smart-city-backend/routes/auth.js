const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const db       = require('../config/db');
const { protect } = require('../middleware/auth');
const router   = express.Router();

// Valid roles that can be registered
const VALID_ROLES = ['Citizen', 'Technician', 'Administrator', 'Councillor'];

// Role → required email domain mapping (matches frontend)
const ROLE_EMAIL_DOMAINS = {
  Citizen:       '@citizen.co.za',
  Technician:    '@technician.gov.za',
  Administrator: '@admin.gov.za',
  Councillor:    '@councillor.gov.za',
};

const signToken = (user) =>
  jwt.sign(
    { id: user.id, email: user.email, role: user.role, full_name: user.full_name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );

// ─────────────────────────────────────────────────────────────────
// POST /api/auth/register
// ─────────────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { id_number, full_name, email, password, phone, role } = req.body;

    console.log('📝 Registration attempt:', { id_number, full_name, email, role });

    // ── Validate required fields ─────────────────────────────────
    if (!id_number || !full_name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required (id_number, full_name, email, password)',
      });
    }

    // ── Validate full name (no numbers) ──────────────────────────
    if (/[0-9]/.test(full_name)) {
      return res.status(400).json({
        success: false,
        message: 'Full name must not contain numbers',
      });
    }

    // ── Validate SA ID (exactly 13 digits) ───────────────────────
    if (!/^\d{13}$/.test(id_number.trim())) {
      return res.status(400).json({
        success: false,
        message: 'SA ID number must be exactly 13 digits',
      });
    }

    // ── Validate password strength ────────────────────────────────
    if (password.length < 8 || password.length > 15) {
      return res.status(400).json({
        success: false,
        message: 'Password must be 8–15 characters long',
      });
    }
    if ((password.match(/[A-Z]/g) || []).length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Password must contain at least 2 uppercase letters',
      });
    }
    if ((password.match(/[0-9]/g) || []).length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Password must contain at least 2 numbers',
      });
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      return res.status(400).json({
        success: false,
        message: 'Password must contain at least 1 special character',
      });
    }

    // ── Determine role ────────────────────────────────────────────
    const assignedRole = (role && VALID_ROLES.includes(role)) ? role : 'Citizen';

    // ── Validate email domain matches role ────────────────────────
    const requiredDomain = ROLE_EMAIL_DOMAINS[assignedRole];
    if (requiredDomain && !email.toLowerCase().endsWith(requiredDomain)) {
      return res.status(400).json({
        success: false,
        message: `Email for ${assignedRole} must end with ${requiredDomain}`,
      });
    }

    // ── Check if email or ID already exists ──────────────────────
    const { rows: existing } = await db.query(
      'SELECT id FROM users WHERE email = $1 OR id_number = $2',
      [email.toLowerCase(), id_number.trim()]
    );
    if (existing.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'Email address or ID number is already registered',
      });
    }

    // ── Hash password ─────────────────────────────────────────────
    const password_hash = await bcrypt.hash(password, 10);

    // ── Insert user ───────────────────────────────────────────────
    const { rows: inserted } = await db.query(
      `INSERT INTO users (id_number, full_name, email, password_hash, role, phone, is_active)
       VALUES ($1, $2, $3, $4, $5, $6, TRUE)
       RETURNING id`,
      [
        id_number.trim(),
        full_name.trim(),
        email.toLowerCase().trim(),
        password_hash,
        assignedRole,
        phone || null,
      ]
    );

    const userId = inserted[0].id;
    console.log(`✅ User registered: ID=${userId}, role=${assignedRole}, email=${email}`);

    // ── Build token ───────────────────────────────────────────────
    const newUser = {
      id:        userId,
      email:     email.toLowerCase().trim(),
      role:      assignedRole,
      full_name: full_name.trim(),
    };
    const token = signToken(newUser);

    res.status(201).json({
      success: true,
      message: `${assignedRole} account created successfully`,
      token,
      user: {
        id:        userId,
        id_number: id_number.trim(),
        full_name: full_name.trim(),
        email:     email.toLowerCase().trim(),
        role:      assignedRole,
        phone:     phone || null,
      },
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error during registration',
      error: err.message,
    });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/auth/login
// ─────────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password required' });
    }

    const { rows } = await db.query(
      'SELECT * FROM users WHERE email = $1',
      [email.toLowerCase().trim()]
    );
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const user = rows[0];

    if (!user.is_active) {
      return res.status(403).json({ success: false, message: 'Account is deactivated. Contact administrator.' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    console.log(`✅ Login: ${user.email} — role: ${user.role}`);

    const token = signToken(user);

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id:        user.id,
        id_number: user.id_number,
        full_name: user.full_name,
        email:     user.email,
        role:      user.role,
        phone:     user.phone,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Server error during login' });
  }
});

// ─────────────────────────────────────────────────────────────────
// GET /api/auth/me
// ─────────────────────────────────────────────────────────────────
router.get('/me', protect, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT id, id_number, full_name, email, role, phone, created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;