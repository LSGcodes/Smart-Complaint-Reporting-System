const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

router.get('/', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { role } = req.query;
    let sql = 'SELECT id, id_number, full_name, email, role, phone, is_active, created_at FROM users';
    const vals = [];
    if (role) { sql += ' WHERE role = $1'; vals.push(role); }
    const result = await db.query(sql, vals);
    res.json({ success: true, users: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch users' });
  }
});

router.get('/technicians', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT u.id, u.full_name, u.email, u.phone, COUNT(a.id) AS active_jobs
       FROM users u LEFT JOIN assignments a ON u.id = a.technician_id
       WHERE u.role = 'Technician' AND u.is_active = TRUE GROUP BY u.id ORDER BY active_jobs ASC`
    );
    res.json({ success: true, technicians: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch technicians' });
  }
});

router.patch('/:id/role', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { role } = req.body;
    await db.query('UPDATE users SET role = $1 WHERE id = $2', [role, req.params.id]);
    res.json({ success: true, message: `Role updated to ${role}` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update role' });
  }
});

module.exports = router;