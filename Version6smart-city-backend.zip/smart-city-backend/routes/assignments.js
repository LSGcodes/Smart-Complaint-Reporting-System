const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

// ─────────────────────────────────────────────────────────────────
// GET /api/assignments
// Admin → all assignments
// Technician → only their own assignments
// ─────────────────────────────────────────────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    let sql, vals = [];

    if (req.user.role === 'Technician') {
      sql = `SELECT a.id AS assignment_id, a.complaint_id, a.assigned_at,
                    a.task_start_date, a.task_end_date, a.notes,
                    c.ref_id, c.category, c.description, c.address,
                    c.latitude, c.longitude, c.status, c.priority,
                    c.citizen_id,
                    u.full_name AS citizen_name
             FROM assignments a
             JOIN complaints c ON a.complaint_id = c.id
             JOIN users u ON c.citizen_id = u.id
             WHERE a.technician_id = $1
             ORDER BY a.assigned_at DESC`;
      vals.push(req.user.id);
    } else {
      // Admin sees all
      sql = `SELECT a.id AS assignment_id, a.complaint_id, a.technician_id, a.assigned_at,
                    a.task_start_date, a.task_end_date, a.notes,
                    c.ref_id, c.category, c.description, c.address,
                    c.latitude, c.longitude, c.status, c.priority,
                    t.full_name AS technician_name, t.email AS technician_email,
                    u.full_name AS citizen_name
             FROM assignments a
             JOIN complaints c ON a.complaint_id = c.id
             JOIN users t ON a.technician_id = t.id
             JOIN users u ON c.citizen_id = u.id
             WHERE c.status NOT IN ('Resolved')
             ORDER BY a.assigned_at DESC`;
    }

    const result = await db.query(sql, vals);
    res.json({ success: true, assignments: result.rows });
  } catch (err) {
    console.error('GET /assignments error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch assignments', error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/assignments — Admin assigns technician to complaint
// ─────────────────────────────────────────────────────────────────
router.post('/', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { complaint_id, technician_id, task_start_date, task_end_date, notes } = req.body;

    console.log('📋 Assigning complaint:', complaint_id, 'to tech:', technician_id);

    if (!complaint_id || !technician_id) {
      return res.status(400).json({
        success: false,
        message: 'complaint_id and technician_id are required',
      });
    }

    // Verify technician exists and is active
    const techResult = await db.query(
      "SELECT id, full_name FROM users WHERE id = $1 AND role = 'Technician' AND is_active = true",
      [technician_id]
    );
    if (techResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Technician not found or inactive' });
    }
    const tech = techResult.rows[0];

    // Verify complaint exists
    const compResult = await db.query(
      'SELECT id, ref_id, status, citizen_id FROM complaints WHERE id = $1',
      [complaint_id]
    );
    if (compResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Complaint not found' });
    }
    const comp = compResult.rows[0];

    // Insert assignment
    const insertResult = await db.query(
      `INSERT INTO assignments (complaint_id, technician_id, assigned_by, task_start_date, task_end_date, notes)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id`,
      [complaint_id, technician_id, req.user.id, task_start_date || null, task_end_date || null, notes || null]
    );
    const newAssignmentId = insertResult.rows[0].id;

    // Update complaint status to Assigned
    const old_status = comp.status;
    await db.query("UPDATE complaints SET status = 'Assigned' WHERE id = $1", [complaint_id]);

    // Log status history
    await db.query(
      `INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes) VALUES ($1, $2, $3, 'Assigned', $4)`,
      [complaint_id, req.user.id, old_status, `Assigned to technician: ${tech.full_name}`]
    );

    // Notify citizen
    await db.query(
      `INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES ($1, $2, 'in_app', 'Technician Assigned', $3)`,
      [comp.citizen_id, complaint_id, `A technician (${tech.full_name}) has been assigned to your complaint ${comp.ref_id}.`]
    );

    // Notify technician
    await db.query(
      `INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES ($1, $2, 'in_app', 'New Job Assigned', $3)`,
      [technician_id, complaint_id, `You have been assigned to complaint ${comp.ref_id}. Please review your job queue.`]
    );

    console.log('✅ Assignment created:', newAssignmentId);

    res.status(201).json({
      success:       true,
      message:       `Complaint ${comp.ref_id} assigned to ${tech.full_name}`,
      assignment_id: newAssignmentId,
    });
  } catch (err) {
    console.error('POST /assignments error:', err);
    res.status(500).json({ success: false, message: 'Failed to assign technician', error: err.message });
  }
});

module.exports = router;