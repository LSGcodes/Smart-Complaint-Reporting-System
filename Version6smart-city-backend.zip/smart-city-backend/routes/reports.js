const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

router.get('/dashboard', protect, async (req, res) => {
  try {
    const categoryStats = await db.query('SELECT * FROM v_category_stats');
    const statusStats   = await db.query('SELECT status, COUNT(*) AS total FROM complaints GROUP BY status');
    const totals        = await db.query(`
      SELECT COUNT(*) AS total_complaints,
        SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) AS resolved,
        SUM(CASE WHEN status != 'Resolved' THEN 1 ELSE 0 END) AS active,
        SUM(CASE WHEN priority IN ('High','Critical') THEN 1 ELSE 0 END) AS high_priority,
        ROUND(AVG(rating)::numeric, 1) AS avg_rating
      FROM complaints`);
    const recent = await db.query(
      'SELECT ref_id, category, status, priority, created_at FROM complaints ORDER BY created_at DESC LIMIT 5'
    );
    res.json({
      success: true,
      totals: totals.rows[0],
      categoryStats: categoryStats.rows,
      statusStats: statusStats.rows,
      recentComplaints: recent.rows
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load dashboard' });
  }
});

router.get('/trend', protect, restrictTo('Administrator', 'Councillor'), async (req, res) => {
  try {
    const monthly = await db.query(`
      SELECT TO_CHAR(created_at, 'YYYY-MM') AS month, COUNT(*) AS total,
             SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) AS resolved
      FROM complaints GROUP BY month ORDER BY month DESC LIMIT 12`);
    res.json({ success: true, monthly: monthly.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load trend data' });
  }
});

module.exports = router;