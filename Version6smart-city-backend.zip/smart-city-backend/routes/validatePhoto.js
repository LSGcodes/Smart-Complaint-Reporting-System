/**
 * ADD THIS ROUTE TO YOUR EXPRESS BACKEND (server.js / routes/complaints.js)
 *
 * Requires:  npm install @anthropic-ai/sdk
 * Env var:   ANTHROPIC_API_KEY=sk-ant-...  (in your .env file)
 *
 * Usage:  POST /api/validate-photo
 *   Body: { image: "<base64>", mediaType: "image/jpeg", category: "Water Leak", description: "..." }
 *   Returns: { relevant: true|false, reason: "...", confidence: "high|medium|low" }
 */

const Anthropic = require("@anthropic-ai/sdk");

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Middleware: verifyToken should already exist in your app — reuse it
// router.post("/api/validate-photo", verifyToken, validatePhotoHandler);

async function validatePhotoHandler(req, res) {
  const { image, mediaType = "image/jpeg", category = "municipal issue", description = "" } = req.body;

  if (!image) return res.status(400).json({ success: false, message: "No image provided" });

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 256,
      system: `You are a photo validator for a South African municipal complaint system.
Decide whether an uploaded photo is relevant to the reported complaint category.
Reply ONLY with valid JSON — no markdown, no extra text:
{"relevant": true, "reason": "brief explanation", "confidence": "high|medium|low"}

Rules:
- Portraits, selfies, family photos, food, cartoons, memes → relevant: false
- A photo showing physical damage/infrastructure that matches the category → relevant: true
- Blurry but plausibly the right issue → relevant: true, confidence: low
- Wrong type of infrastructure (e.g. a lamp post for a water leak) → relevant: false`,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: { type: "base64", media_type: mediaType, data: image },
            },
            {
              type: "text",
              text: `Category: "${category}". Description: "${description}". Is this photo relevant?`,
            },
          ],
        },
      ],
    });

    const raw = response.content.find((b) => b.type === "text")?.text || "{}";
    let result;
    try {
      result = JSON.parse(raw.replace(/```json|```/g, "").trim());
    } catch {
      result = { relevant: true, reason: "Parse error — defaulting to accept", confidence: "low" };
    }

    return res.json({ success: true, ...result });
  } catch (err) {
    console.error("Photo validation error:", err.message);
    return res.status(500).json({ success: false, relevant: false, reason: "Validation service error" });
  }
}

module.exports = { validatePhotoHandler };

/* ─── HOW TO WIRE IT INTO YOUR APP ────────────────────────────────────
   In your server.js (or wherever you define routes), add:

   const { validatePhotoHandler } = require("./validate-photo-route");
   app.post("/api/validate-photo", verifyToken, validatePhotoHandler);

   And in your .env file:
   ANTHROPIC_API_KEY=sk-ant-your-key-here
─────────────────────────────────────────────────────────────────────── */
