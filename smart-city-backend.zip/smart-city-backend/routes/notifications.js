const express = require('express');
const db      = require('../config/db');
const { protect } = require('../middleware/auth');
const router  = express.Router();

router.get('/', protect, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT n.*, c.ref_id FROM notifications n
       LEFT JOIN complaints c ON n.complaint_id = c.id
       WHERE n.user_id = ? ORDER BY n.sent_at DESC LIMIT 50`,
      [req.user.id]
    );
    res.json({ success: true, unread: rows.filter(n => !n.is_read).length, notifications: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch notifications' });
  }
});

router.patch('/read-all', protect, async (req, res) => {
  try {
    await db.query('UPDATE notifications SET is_read = TRUE WHERE user_id = ?', [req.user.id]);
    res.json({ success: true, message: 'All marked as read' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to mark notifications' });
  }
});

module.exports = router;