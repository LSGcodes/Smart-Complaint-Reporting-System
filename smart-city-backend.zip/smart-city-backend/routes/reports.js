const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

router.get('/dashboard', protect, async (req, res) => {
  try {
    const [categoryStats] = await db.query('SELECT * FROM v_category_stats');
    const [statusStats]   = await db.query('SELECT status, COUNT(*) AS total FROM complaints GROUP BY status');
    const [totals]        = await db.query(`
      SELECT COUNT(*) AS total_complaints,
        SUM(status = 'Resolved') AS resolved,
        SUM(status != 'Resolved') AS active,
        SUM(priority IN ('High','Critical')) AS high_priority,
        ROUND(AVG(rating),1) AS avg_rating
      FROM complaints`);
    const [recent] = await db.query(
      'SELECT ref_id, category, status, priority, created_at FROM complaints ORDER BY created_at DESC LIMIT 5'
    );
    res.json({ success: true, totals: totals[0], categoryStats, statusStats, recentComplaints: recent });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load dashboard' });
  }
});

router.get('/trend', protect, restrictTo('Administrator', 'Councillor'), async (req, res) => {
  try {
    const [monthly] = await db.query(`
      SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS total,
             SUM(status = 'Resolved') AS resolved
      FROM complaints GROUP BY month ORDER BY month DESC LIMIT 12`);
    res.json({ success: true, monthly });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load trend data' });
  }
});

module.exports = router;