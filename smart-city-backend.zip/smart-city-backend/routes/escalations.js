const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

router.get('/', protect, restrictTo('Councillor', 'Administrator'), async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM v_council_queue');
    res.json({ success: true, escalations: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch escalations' });
  }
});

router.patch('/:id/decision', protect, restrictTo('Councillor'), async (req, res) => {
  try {
    const { decision, decision_notes } = req.body;
    await db.query(
      'UPDATE escalations SET decision = ?, decision_notes = ?, decided_at = NOW() WHERE id = ?',
      [decision, decision_notes || null, req.params.id]
    );
    res.json({ success: true, message: 'Decision recorded' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to log decision' });
  }
});

module.exports = router;