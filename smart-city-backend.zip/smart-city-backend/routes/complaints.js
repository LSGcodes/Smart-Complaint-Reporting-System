const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const multer  = require('multer');
const path    = require('path');
const router  = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename:    (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

const genRefId = async () => {
  const [rows] = await db.query('SELECT COUNT(*) AS cnt FROM complaints');
  return `CMP-${String(rows[0].cnt + 1).padStart(3, '0')}`;
};

router.get('/', protect, async (req, res) => {
  try {
    const { status, category, priority } = req.query;
    let sql = 'SELECT * FROM v_complaints_full WHERE 1=1';
    const vals = [];
    if (req.user.role === 'Citizen') { sql += ' AND citizen_id = ?'; vals.push(req.user.id); }
    if (status)   { sql += ' AND status = ?';   vals.push(status); }
    if (category) { sql += ' AND category = ?'; vals.push(category); }
    if (priority) { sql += ' AND priority = ?'; vals.push(priority); }
    sql += ' ORDER BY created_at DESC';
    const [rows] = await db.query(sql, vals);
    res.json({ success: true, count: rows.length, complaints: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch complaints' });
  }
});

router.get('/:id', protect, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM v_complaints_full WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Not found' });
    const [history] = await db.query(
      `SELECT sh.*, u.full_name AS changed_by_name FROM status_history sh
       JOIN users u ON sh.changed_by = u.id WHERE sh.complaint_id = ? ORDER BY sh.changed_at ASC`,
      [req.params.id]
    );
    res.json({ success: true, complaint: rows[0], history });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch complaint' });
  }
});

router.post('/', protect, restrictTo('Citizen'), upload.single('photo'), async (req, res) => {
  try {
    const { category, description, address, latitude, longitude } = req.body;
    if (!category || !description)
      return res.status(400).json({ success: false, message: 'Category and description required' });

    const ref_id    = await genRefId();
    const photo_url = req.file ? `/uploads/${req.file.filename}` : null;

    const [result] = await db.query(
      `INSERT INTO complaints (ref_id, citizen_id, category, description, address, latitude, longitude, photo_url, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Submitted')`,
      [ref_id, req.user.id, category, description, address, latitude || null, longitude || null, photo_url]
    );
    await db.query(
      'INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes) VALUES (?, ?, NULL, ?, ?)',
      [result.insertId, req.user.id, 'Submitted', 'Complaint submitted by citizen']
    );
    res.status(201).json({ success: true, message: 'Complaint submitted', ref_id, complaint_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to submit complaint' });
  }
});

router.patch('/:id/status', protect, restrictTo('Technician', 'Administrator'), async (req, res) => {
  try {
    const { status, notes } = req.body;
    const [rows] = await db.query('SELECT status, citizen_id FROM complaints WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Not found' });
    const old_status = rows[0].status;
    await db.query('UPDATE complaints SET status = ? WHERE id = ?', [status, req.params.id]);
    await db.query(
      'INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes) VALUES (?, ?, ?, ?, ?)',
      [req.params.id, req.user.id, old_status, status, notes || null]
    );
    await db.query(
      'INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES (?, ?, ?, ?, ?)',
      [rows[0].citizen_id, req.params.id, 'in_app', 'Complaint Update', `Your complaint is now: ${status}`]
    );
    res.json({ success: true, message: `Status updated to ${status}` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update status' });
  }
});

router.post('/:id/rate', protect, restrictTo('Citizen'), async (req, res) => {
  try {
    const { rating, comment } = req.body;
    if (!rating || rating < 1 || rating > 5)
      return res.status(400).json({ success: false, message: 'Rating must be 1-5' });
    await db.query('UPDATE complaints SET rating = ?, rating_comment = ? WHERE id = ? AND citizen_id = ?',
      [rating, comment || null, req.params.id, req.user.id]);
    res.json({ success: true, message: 'Rating submitted!' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to submit rating' });
  }
});

router.post('/:id/request-review', protect, restrictTo('Citizen'), async (req, res) => {
  try {
    await db.query('UPDATE complaints SET council_review_requested = TRUE WHERE id = ? AND citizen_id = ?',
      [req.params.id, req.user.id]);
    const [councillors] = await db.query('SELECT id FROM users WHERE role = ? LIMIT 1', ['Councillor']);
    if (councillors.length > 0) {
      await db.query(
        `INSERT INTO escalations (complaint_id, councillor_id, escalated_by, escalation_type) VALUES (?, ?, ?, 'citizen_request')`,
        [req.params.id, councillors[0].id, req.user.id]
      );
    }
    res.json({ success: true, message: 'Council review requested' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to request review' });
  }
});

module.exports = router;