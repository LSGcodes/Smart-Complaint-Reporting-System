const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const db      = require('../config/db');
const { protect } = require('../middleware/auth');
const router  = express.Router();

const signToken = (user) => jwt.sign(
  { id: user.id, email: user.email, role: user.role, full_name: user.full_name },
  process.env.JWT_SECRET,
  { expiresIn: process.env.JWT_EXPIRES_IN }
);

router.post('/register', async (req, res) => {
  try {
    const { id_number, full_name, email, password, phone } = req.body;
    if (!id_number || !full_name || !email || !password)
      return res.status(400).json({ success: false, message: 'All fields are required' });

    const [existing] = await db.query('SELECT id FROM users WHERE email = ? OR id_number = ?', [email, id_number]);
    if (existing.length > 0)
      return res.status(409).json({ success: false, message: 'Email or ID already registered' });

    const password_hash = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      'INSERT INTO users (id_number, full_name, email, password_hash, role, phone) VALUES (?, ?, ?, ?, ?, ?)',
      [id_number, full_name, email, password_hash, 'Citizen', phone || null]
    );
    const newUser = { id: result.insertId, email, role: 'Citizen', full_name };
    res.status(201).json({ success: true, token: signToken(newUser), user: newUser });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ success: false, message: 'Email and password required' });

    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0)
      return res.status(401).json({ success: false, message: 'Invalid email or password' });

    const user = rows[0];
    if (!user.is_active)
      return res.status(403).json({ success: false, message: 'Account deactivated' });

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch)
      return res.status(401).json({ success: false, message: 'Invalid email or password' });

    res.json({
      success: true,
      token: signToken(user),
      user: { id: user.id, id_number: user.id_number, full_name: user.full_name, email: user.email, role: user.role, phone: user.phone }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.get('/me', protect, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, id_number, full_name, email, role, phone FROM users WHERE id = ?', [req.user.id]
    );
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;