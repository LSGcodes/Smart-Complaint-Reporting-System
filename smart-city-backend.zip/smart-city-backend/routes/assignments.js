const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

router.get('/', protect, async (req, res) => {
  try {
    let sql = 'SELECT * FROM v_active_assignments';
    const vals = [];
    if (req.user.role === 'Technician') {
      sql = `SELECT a.*, c.ref_id, c.category, c.description, c.address, c.status, c.priority
             FROM assignments a JOIN complaints c ON a.complaint_id = c.id
             WHERE a.technician_id = ? ORDER BY a.assigned_at DESC`;
      vals.push(req.user.id);
    }
    const [rows] = await db.query(sql, vals);
    res.json({ success: true, assignments: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch assignments' });
  }
});

router.post('/', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { complaint_id, technician_id, task_start_date, task_end_date, notes } = req.body;
    if (!complaint_id || !technician_id)
      return res.status(400).json({ success: false, message: 'complaint_id and technician_id required' });

    const [result] = await db.query(
      'INSERT INTO assignments (complaint_id, technician_id, assigned_by, task_start_date, task_end_date, notes) VALUES (?, ?, ?, ?, ?, ?)',
      [complaint_id, technician_id, req.user.id, task_start_date || null, task_end_date || null, notes || null]
    );
    const [comp] = await db.query('SELECT status, citizen_id FROM complaints WHERE id = ?', [complaint_id]);
    if (comp.length > 0) {
      await db.query("UPDATE complaints SET status = 'Assigned' WHERE id = ?", [complaint_id]);
      await db.query(
        'INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes) VALUES (?, ?, ?, ?, ?)',
        [complaint_id, req.user.id, comp[0].status, 'Assigned', 'Assigned to technician']
      );
    }
    res.status(201).json({ success: true, message: 'Technician assigned', assignment_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to assign technician' });
  }
});

module.exports = router;