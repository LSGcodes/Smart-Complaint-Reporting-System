const express = require('express');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');
require('dotenv').config();

// ─── Route imports ────────────────────────────────────────
const authRoutes          = require('./routes/auth');
const complaintsRoutes    = require('./routes/complaints');
const usersRoutes         = require('./routes/users');
const assignmentsRoutes   = require('./routes/assignments');
const escalationsRoutes   = require('./routes/escalations');
const notificationsRoutes = require('./routes/notifications');
const reportsRoutes       = require('./routes/reports');

const app = express();

// ─── Create uploads folder if missing ────────────────────
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

// ─── Middleware ───────────────────────────────────────────
app.use(cors({
  origin:      process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded photos
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ─── Health check ─────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: '🏙️ Smart City API is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
  });
});

// ─── Routes ───────────────────────────────────────────────
app.use('/api/auth',          authRoutes);
app.use('/api/complaints',    complaintsRoutes);
app.use('/api/users',         usersRoutes);
app.use('/api/assignments',   assignmentsRoutes);
app.use('/api/escalations',   escalationsRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/reports',       reportsRoutes);

// ─── 404 handler ─────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.url}` });
});

// ─── Global error handler ────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.message);
  res.status(500).json({ success: false, message: err.message || 'Internal server error' });
});

// ─── Start server ─────────────────────────────────────────
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════╗');
  console.log('║  🏙️  Smart City Backend API           ║');
  console.log(`║  Running on http://localhost:${PORT}    ║`);
  console.log('╚══════════════════════════════════════╝');
  console.log('');
  console.log('  Routes available:');
  console.log('  POST   /api/auth/register');
  console.log('  POST   /api/auth/login');
  console.log('  GET    /api/auth/me');
  console.log('  GET    /api/complaints');
  console.log('  POST   /api/complaints');
  console.log('  GET    /api/assignments');
  console.log('  POST   /api/assignments');
  console.log('  GET    /api/escalations');
  console.log('  GET    /api/notifications');
  console.log('  GET    /api/reports/dashboard');
  console.log('  GET    /api/health');
  console.log('');
});

module.exports = app;
