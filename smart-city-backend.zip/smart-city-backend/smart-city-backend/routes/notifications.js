const express = require('express');
const db      = require('../config/db');
const { protect } = require('../middleware/auth');

const router = express.Router();

// ─────────────────────────────────────────────────────────
// GET /api/notifications  — get my notifications
// ─────────────────────────────────────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT n.*, c.ref_id
       FROM notifications n
       LEFT JOIN complaints c ON n.complaint_id = c.id
       WHERE n.user_id = ?
       ORDER BY n.sent_at DESC
       LIMIT 50`,
      [req.user.id]
    );
    const unread = rows.filter(n => !n.is_read).length;
    res.json({ success: true, unread, notifications: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch notifications' });
  }
});

// ─────────────────────────────────────────────────────────
// PATCH /api/notifications/:id/read  — mark as read
// ─────────────────────────────────────────────────────────
router.patch('/:id/read', protect, async (req, res) => {
  try {
    await db.query(
      'UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );
    res.json({ success: true, message: 'Marked as read' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to mark notification' });
  }
});

// ─────────────────────────────────────────────────────────
// PATCH /api/notifications/read-all  — mark all as read
// ─────────────────────────────────────────────────────────
router.patch('/read-all', protect, async (req, res) => {
  try {
    await db.query(
      'UPDATE notifications SET is_read = TRUE WHERE user_id = ?',
      [req.user.id]
    );
    res.json({ success: true, message: 'All notifications marked as read' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to mark all' });
  }
});

module.exports = router;
