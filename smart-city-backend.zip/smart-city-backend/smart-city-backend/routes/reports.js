const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');

const router = express.Router();

// ─────────────────────────────────────────────────────────
// GET /api/reports/dashboard  — summary stats for all roles
// ─────────────────────────────────────────────────────────
router.get('/dashboard', protect, async (req, res) => {
  try {
    // Stats per category
    const [categoryStats] = await db.query('SELECT * FROM v_category_stats');

    // Stats per status
    const [statusStats] = await db.query(
      `SELECT status, COUNT(*) AS total FROM complaints GROUP BY status`
    );

    // Stats per priority
    const [priorityStats] = await db.query(
      `SELECT priority, COUNT(*) AS total FROM complaints GROUP BY priority`
    );

    // Total counts
    const [totals] = await db.query(`
      SELECT
        COUNT(*) AS total_complaints,
        SUM(status = 'Resolved') AS resolved,
        SUM(status != 'Resolved') AS active,
        SUM(priority IN ('High','Critical')) AS high_priority,
        ROUND(AVG(rating), 1) AS avg_rating
      FROM complaints
    `);

    // Recent complaints (last 5)
    const [recent] = await db.query(
      'SELECT ref_id, category, status, priority, created_at FROM complaints ORDER BY created_at DESC LIMIT 5'
    );

    res.json({
      success: true,
      totals: totals[0],
      categoryStats,
      statusStats,
      priorityStats,
      recentComplaints: recent,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to load dashboard stats' });
  }
});

// ─────────────────────────────────────────────────────────
// GET /api/reports/trend  — AI trend analysis (Admin)
// ─────────────────────────────────────────────────────────
router.get('/trend', protect, restrictTo('Administrator', 'Councillor'), async (req, res) => {
  try {
    // Monthly complaint volume
    const [monthly] = await db.query(`
      SELECT
        DATE_FORMAT(created_at, '%Y-%m') AS month,
        COUNT(*) AS total,
        SUM(status = 'Resolved') AS resolved
      FROM complaints
      GROUP BY month
      ORDER BY month DESC
      LIMIT 12
    `);

    // Top complaint locations
    const [locations] = await db.query(`
      SELECT address, category, COUNT(*) AS count, AVG(latitude) AS lat, AVG(longitude) AS lng
      FROM complaints
      WHERE address IS NOT NULL
      GROUP BY address, category
      ORDER BY count DESC
      LIMIT 10
    `);

    // Average resolution time (days)
    const [resolutionTime] = await db.query(`
      SELECT
        category,
        ROUND(AVG(DATEDIFF(updated_at, created_at)), 1) AS avg_days
      FROM complaints
      WHERE status = 'Resolved'
      GROUP BY category
    `);

    res.json({ success: true, monthly, locations, resolutionTime });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to load trend data' });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/reports/generate  — Admin: log a report
// ─────────────────────────────────────────────────────────
router.post('/generate', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { report_type, title, date_from, date_to } = req.body;

    const [result] = await db.query(
      'INSERT INTO reports (generated_by, report_type, title, date_from, date_to) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, report_type, title, date_from || null, date_to || null]
    );

    res.status(201).json({ success: true, message: 'Report logged', report_id: result.insertId });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to generate report' });
  }
});

module.exports = router;
