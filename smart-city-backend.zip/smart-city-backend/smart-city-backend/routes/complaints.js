const express  = require('express');
const db       = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const multer   = require('multer');
const path     = require('path');

const router = express.Router();

// ─── File upload setup (photos) ─────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename:    (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    if (allowed.test(path.extname(file.originalname).toLowerCase())) cb(null, true);
    else cb(new Error('Only image files allowed'));
  },
});

// ─── Helper: generate ref_id ────────────────────────────
const genRefId = async () => {
  const [rows] = await db.query('SELECT COUNT(*) AS cnt FROM complaints');
  const num = rows[0].cnt + 1;
  return `CMP-${String(num).padStart(3, '0')}`;
};

// ─────────────────────────────────────────────────────────
// GET /api/complaints
// Citizen: own complaints | Admin/Councillor/Technician: all
// ─────────────────────────────────────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    const { status, category, priority } = req.query;
    let sql    = 'SELECT * FROM v_complaints_full WHERE 1=1';
    const vals = [];

    // Citizens only see their own complaints
    if (req.user.role === 'Citizen') {
      sql += ' AND citizen_id = ?';
      vals.push(req.user.id);
    }

    if (status)   { sql += ' AND status = ?';   vals.push(status); }
    if (category) { sql += ' AND category = ?'; vals.push(category); }
    if (priority) { sql += ' AND priority = ?'; vals.push(priority); }

    sql += ' ORDER BY created_at DESC';

    const [rows] = await db.query(sql, vals);
    res.json({ success: true, count: rows.length, complaints: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to fetch complaints' });
  }
});

// ─────────────────────────────────────────────────────────
// GET /api/complaints/:id
// ─────────────────────────────────────────────────────────
router.get('/:id', protect, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM v_complaints_full WHERE id = ?',
      [req.params.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Complaint not found' });
    }

    // Citizens can only view their own
    const c = rows[0];
    if (req.user.role === 'Citizen' && c.citizen_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    // Get status history
    const [history] = await db.query(
      `SELECT sh.*, u.full_name AS changed_by_name
       FROM status_history sh
       JOIN users u ON sh.changed_by = u.id
       WHERE sh.complaint_id = ?
       ORDER BY sh.changed_at ASC`,
      [req.params.id]
    );

    res.json({ success: true, complaint: c, history });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to fetch complaint' });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/complaints  — submit new complaint (Citizen)
// ─────────────────────────────────────────────────────────
router.post('/', protect, restrictTo('Citizen'), upload.single('photo'), async (req, res) => {
  try {
    const { category, description, address, latitude, longitude } = req.body;

    if (!category || !description) {
      return res.status(400).json({ success: false, message: 'Category and description are required' });
    }

    const ref_id    = await genRefId();
    const photo_url = req.file ? `/uploads/${req.file.filename}` : null;

    const [result] = await db.query(
      `INSERT INTO complaints
         (ref_id, citizen_id, category, description, address, latitude, longitude, photo_url, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Submitted')`,
      [ref_id, req.user.id, category, description, address, latitude || null, longitude || null, photo_url]
    );

    const complaintId = result.insertId;

    // Log initial status history
    await db.query(
      'INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes) VALUES (?, ?, NULL, ?, ?)',
      [complaintId, req.user.id, 'Submitted', 'Complaint submitted by citizen']
    );

    // Create notification for citizen
    await db.query(
      'INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, complaintId, 'in_app', 'Complaint Submitted', `Your complaint ${ref_id} has been submitted and is being processed.`]
    );

    res.status(201).json({
      success: true,
      message: 'Complaint submitted successfully',
      ref_id,
      complaint_id: complaintId,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to submit complaint' });
  }
});

// ─────────────────────────────────────────────────────────
// PATCH /api/complaints/:id/status  — update status
// Technician: In Progress / Resolved
// Admin: any status
// ─────────────────────────────────────────────────────────
router.patch('/:id/status', protect, restrictTo('Technician', 'Administrator'), async (req, res) => {
  try {
    const { status, notes } = req.body;
    const validStatuses = ['Submitted', 'Classified', 'Assigned', 'In Progress', 'Resolved'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status value' });
    }

    // Get current status
    const [rows] = await db.query('SELECT status, citizen_id FROM complaints WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Complaint not found' });

    const old_status = rows[0].status;
    const citizen_id = rows[0].citizen_id;

    // Update complaint
    await db.query('UPDATE complaints SET status = ? WHERE id = ?', [status, req.params.id]);

    // Log history
    await db.query(
      'INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes) VALUES (?, ?, ?, ?, ?)',
      [req.params.id, req.user.id, old_status, status, notes || null]
    );

    // Notify citizen
    await db.query(
      'INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES (?, ?, ?, ?, ?)',
      [citizen_id, req.params.id, 'in_app', 'Complaint Update',
       `Your complaint is now: ${status}.${status === 'Resolved' ? ' Please rate the service.' : ''}`]
    );

    res.json({ success: true, message: `Status updated to ${status}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to update status' });
  }
});

// ─────────────────────────────────────────────────────────
// PATCH /api/complaints/:id/classify  — AI classification (Admin)
// ─────────────────────────────────────────────────────────
router.patch('/:id/classify', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { category, priority, ai_category, ai_priority, confidence, admin_override } = req.body;

    await db.query(
      `UPDATE complaints
       SET category = ?, priority = ?, ai_category = ?, ai_priority = ?,
           admin_overridden = ?, status = 'Classified'
       WHERE id = ?`,
      [category, priority, ai_category || category, ai_priority || priority,
       admin_override ? true : false, req.params.id]
    );

    // Log AI result
    if (confidence) {
      await db.query(
        'INSERT INTO ai_logs (complaint_id, predicted_cat, predicted_pri, confidence, model_version) VALUES (?, ?, ?, ?, ?)',
        [req.params.id, ai_category, ai_priority, confidence, 'nlp-v1.0']
      );
    }

    res.json({ success: true, message: 'Complaint classified successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to classify complaint' });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/complaints/:id/rate  — rate resolved complaint (Citizen)
// ─────────────────────────────────────────────────────────
router.post('/:id/rate', protect, restrictTo('Citizen'), async (req, res) => {
  try {
    const { rating, comment } = req.body;

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ success: false, message: 'Rating must be between 1 and 5' });
    }

    const [rows] = await db.query(
      'SELECT status, citizen_id FROM complaints WHERE id = ?', [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Complaint not found' });
    if (rows[0].citizen_id !== req.user.id) return res.status(403).json({ success: false, message: 'Access denied' });
    if (rows[0].status !== 'Resolved') return res.status(400).json({ success: false, message: 'Can only rate resolved complaints' });

    await db.query(
      'UPDATE complaints SET rating = ?, rating_comment = ? WHERE id = ?',
      [rating, comment || null, req.params.id]
    );

    res.json({ success: true, message: 'Rating submitted — thank you!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to submit rating' });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/complaints/:id/request-review  — Request Council Review (Citizen)
// ─────────────────────────────────────────────────────────
router.post('/:id/request-review', protect, restrictTo('Citizen'), async (req, res) => {
  try {
    // Mark complaint
    await db.query(
      'UPDATE complaints SET council_review_requested = TRUE WHERE id = ? AND citizen_id = ?',
      [req.params.id, req.user.id]
    );

    // Find a Councillor to notify
    const [councillors] = await db.query('SELECT id FROM users WHERE role = ? LIMIT 1', ['Councillor']);
    if (councillors.length > 0) {
      const councillor_id = councillors[0].id;

      // Create escalation record
      await db.query(
        `INSERT INTO escalations (complaint_id, councillor_id, escalated_by, escalation_type)
         VALUES (?, ?, ?, 'citizen_request')`,
        [req.params.id, councillor_id, req.user.id]
      );

      // Notify councillor
      await db.query(
        'INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES (?, ?, ?, ?, ?)',
        [councillor_id, req.params.id, 'in_app', 'Council Review Requested',
         `A citizen has requested council review for complaint ID ${req.params.id}.`]
      );
    }

    res.json({ success: true, message: 'Council review requested successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to request review' });
  }
});

module.exports = router;
