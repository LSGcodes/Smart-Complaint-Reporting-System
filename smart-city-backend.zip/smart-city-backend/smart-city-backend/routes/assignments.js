const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');

const router = express.Router();

// ─────────────────────────────────────────────────────────
// GET /api/assignments  — Admin: all | Technician: own jobs
// ─────────────────────────────────────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    let sql = 'SELECT * FROM v_active_assignments';
    const vals = [];

    if (req.user.role === 'Technician') {
      sql = `SELECT a.*, c.ref_id, c.category, c.description, c.address,
                    c.latitude, c.longitude, c.status, c.priority
             FROM assignments a
             JOIN complaints c ON a.complaint_id = c.id
             WHERE a.technician_id = ?
             ORDER BY a.assigned_at DESC`;
      vals.push(req.user.id);
    }

    const [rows] = await db.query(sql, vals);
    res.json({ success: true, assignments: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch assignments' });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/assignments  — Admin: assign technician
// ─────────────────────────────────────────────────────────
router.post('/', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { complaint_id, technician_id, task_start_date, task_end_date, notes } = req.body;

    if (!complaint_id || !technician_id) {
      return res.status(400).json({ success: false, message: 'complaint_id and technician_id required' });
    }

    // Check technician exists and is active
    const [tech] = await db.query(
      'SELECT id, full_name FROM users WHERE id = ? AND role = ? AND is_active = TRUE',
      [technician_id, 'Technician']
    );
    if (tech.length === 0) {
      return res.status(404).json({ success: false, message: 'Technician not found or inactive' });
    }

    // Insert assignment
    const [result] = await db.query(
      `INSERT INTO assignments (complaint_id, technician_id, assigned_by, task_start_date, task_end_date, notes)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [complaint_id, technician_id, req.user.id, task_start_date || null, task_end_date || null, notes || null]
    );

    // Update complaint status to Assigned
    const [comp] = await db.query('SELECT status, citizen_id FROM complaints WHERE id = ?', [complaint_id]);
    if (comp.length > 0) {
      await db.query("UPDATE complaints SET status = 'Assigned' WHERE id = ?", [complaint_id]);

      // Log status history
      await db.query(
        'INSERT INTO status_history (complaint_id, changed_by, old_status, new_status, notes) VALUES (?, ?, ?, ?, ?)',
        [complaint_id, req.user.id, comp[0].status, 'Assigned', `Assigned to technician: ${tech[0].full_name}`]
      );

      // Notify citizen
      await db.query(
        'INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES (?, ?, ?, ?, ?)',
        [comp[0].citizen_id, complaint_id, 'in_app', 'Technician Assigned',
         `A technician (${tech[0].full_name}) has been assigned to your complaint.`]
      );

      // Notify technician
      await db.query(
        'INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES (?, ?, ?, ?, ?)',
        [technician_id, complaint_id, 'in_app', 'New Job Assigned',
         `You have been assigned to a new complaint. Please check your job list.`]
      );
    }

    res.status(201).json({ success: true, message: 'Technician assigned successfully', assignment_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to assign technician' });
  }
});

module.exports = router;
