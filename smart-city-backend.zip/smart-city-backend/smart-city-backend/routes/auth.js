const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const db       = require('../config/db');
const { protect } = require('../middleware/auth');

const router = express.Router();

// ─── Helper: generate JWT ────────────────────────────────
const signToken = (user) =>
  jwt.sign(
    { id: user.id, email: user.email, role: user.role, full_name: user.full_name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );

// ─────────────────────────────────────────────────────────
// POST /api/auth/register
// ─────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { id_number, full_name, email, password, phone } = req.body;

    // Validate required fields
    if (!id_number || !full_name || !email || !password) {
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Check if email or ID already exists
    const [existing] = await db.query(
      'SELECT id FROM users WHERE email = ? OR id_number = ?',
      [email, id_number]
    );
    if (existing.length > 0) {
      return res.status(409).json({ success: false, message: 'Email or ID number already registered' });
    }

    // Hash password
    const password_hash = await bcrypt.hash(password, 10);

    // Insert user (always Citizen on self-register)
    const [result] = await db.query(
      'INSERT INTO users (id_number, full_name, email, password_hash, role, phone) VALUES (?, ?, ?, ?, ?, ?)',
      [id_number, full_name, email, password_hash, 'Citizen', phone || null]
    );

    const newUser = { id: result.insertId, email, role: 'Citizen', full_name };
    const token   = signToken(newUser);

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token,
      user: { id: result.insertId, id_number, full_name, email, role: 'Citizen', phone },
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Server error during registration' });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/auth/login
// ─────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password required' });
    }

    // Find user
    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const user = rows[0];

    // Check active
    if (!user.is_active) {
      return res.status(403).json({ success: false, message: 'Account is deactivated' });
    }

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const token = signToken(user);

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id:        user.id,
        id_number: user.id_number,
        full_name: user.full_name,
        email:     user.email,
        role:      user.role,
        phone:     user.phone,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Server error during login' });
  }
});

// ─────────────────────────────────────────────────────────
// GET /api/auth/me  — get logged-in user profile
// ─────────────────────────────────────────────────────────
router.get('/me', protect, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, id_number, full_name, email, role, phone, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
