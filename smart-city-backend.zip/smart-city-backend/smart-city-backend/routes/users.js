const express = require('express');
const bcrypt  = require('bcryptjs');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');

const router = express.Router();

// ─────────────────────────────────────────────────────────
// GET /api/users  — Admin: list all users
// ─────────────────────────────────────────────────────────
router.get('/', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { role } = req.query;
    let sql = 'SELECT id, id_number, full_name, email, role, phone, is_active, created_at FROM users';
    const vals = [];
    if (role) { sql += ' WHERE role = ?'; vals.push(role); }
    sql += ' ORDER BY created_at DESC';
    const [rows] = await db.query(sql, vals);
    res.json({ success: true, count: rows.length, users: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch users' });
  }
});

// ─────────────────────────────────────────────────────────
// GET /api/users/technicians  — list available technicians
// ─────────────────────────────────────────────────────────
router.get('/technicians', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.full_name, u.email, u.phone,
              COUNT(a.id) AS active_jobs
       FROM users u
       LEFT JOIN assignments a ON u.id = a.technician_id
         AND a.complaint_id IN (SELECT id FROM complaints WHERE status NOT IN ('Resolved'))
       WHERE u.role = 'Technician' AND u.is_active = TRUE
       GROUP BY u.id
       ORDER BY active_jobs ASC`
    );
    res.json({ success: true, technicians: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch technicians' });
  }
});

// ─────────────────────────────────────────────────────────
// PATCH /api/users/:id/role  — Admin: change user role
// ─────────────────────────────────────────────────────────
router.patch('/:id/role', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { role } = req.body;
    const validRoles = ['Citizen', 'Technician', 'Administrator', 'Councillor'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role' });
    }
    await db.query('UPDATE users SET role = ? WHERE id = ?', [role, req.params.id]);
    res.json({ success: true, message: `User role updated to ${role}` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update role' });
  }
});

// ─────────────────────────────────────────────────────────
// PATCH /api/users/:id/toggle  — Admin: activate/deactivate
// ─────────────────────────────────────────────────────────
router.patch('/:id/toggle', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    await db.query('UPDATE users SET is_active = NOT is_active WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'User status toggled' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to toggle user' });
  }
});

module.exports = router;
