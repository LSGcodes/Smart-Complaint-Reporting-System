const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');

const router = express.Router();

// ─────────────────────────────────────────────────────────
// GET /api/escalations  — Councillor: council queue
// ─────────────────────────────────────────────────────────
router.get('/', protect, restrictTo('Councillor', 'Administrator'), async (req, res) => {
  try {
    let sql = 'SELECT * FROM v_council_queue';
    const vals = [];

    if (req.user.role === 'Councillor') {
      sql += ' WHERE councillor_name = (SELECT full_name FROM users WHERE id = ?)';
      vals.push(req.user.id);
    }

    const [rows] = await db.query(sql, vals);
    res.json({ success: true, count: rows.length, escalations: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch escalations' });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/escalations  — Admin: escalate to councillor
// ─────────────────────────────────────────────────────────
router.post('/', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { complaint_id, councillor_id } = req.body;

    if (!complaint_id || !councillor_id) {
      return res.status(400).json({ success: false, message: 'complaint_id and councillor_id required' });
    }

    const [result] = await db.query(
      `INSERT INTO escalations (complaint_id, councillor_id, escalated_by, escalation_type)
       VALUES (?, ?, ?, 'auto')`,
      [complaint_id, councillor_id, req.user.id]
    );

    // Notify councillor
    await db.query(
      'INSERT INTO notifications (user_id, complaint_id, type, subject, message) VALUES (?, ?, ?, ?, ?)',
      [councillor_id, complaint_id, 'in_app', 'High Priority Escalation',
       `A High/Critical complaint has been escalated to your queue for review.`]
    );

    res.status(201).json({ success: true, message: 'Complaint escalated to councillor', escalation_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to escalate complaint' });
  }
});

// ─────────────────────────────────────────────────────────
// PATCH /api/escalations/:id/decision  — Councillor: log decision
// ─────────────────────────────────────────────────────────
router.patch('/:id/decision', protect, restrictTo('Councillor'), async (req, res) => {
  try {
    const { decision, decision_notes } = req.body;

    const validDecisions = [
      'Approved Emergency Budget',
      'Direct Resources',
      'Escalate to Management',
      'Schedule Site Visit',
      'Pending',
    ];

    if (!validDecisions.includes(decision)) {
      return res.status(400).json({ success: false, message: 'Invalid decision value' });
    }

    await db.query(
      'UPDATE escalations SET decision = ?, decision_notes = ?, decided_at = NOW() WHERE id = ?',
      [decision, decision_notes || null, req.params.id]
    );

    res.json({ success: true, message: 'Council decision recorded' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to log decision' });
  }
});

module.exports = router;
