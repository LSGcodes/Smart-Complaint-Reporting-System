const express = require('express');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');
require('dotenv').config();

const app = express();

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

app.use(cors({ origin: '*', credentials: false }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/api/health', (req, res) => res.json({ success: true, message: '🏙️ Smart City API is running' }));

app.use('/api/auth',          require('./routes/auth'));
app.use('/api/complaints',    require('./routes/complaints'));
app.use('/api/users',         require('./routes/users'));
app.use('/api/assignments',   require('./routes/assignments'));
app.use('/api/escalations',   require('./routes/escalations'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/reports',       require('./routes/reports'));

app.use((req, res) => res.status(404).json({ success: false, message: 'Route not found' }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════╗');
  console.log('║  🏙️  Smart City API running           ║');
  console.log(`║  http://localhost:${PORT}              ║`);
  console.log('╚══════════════════════════════════════╝');
});