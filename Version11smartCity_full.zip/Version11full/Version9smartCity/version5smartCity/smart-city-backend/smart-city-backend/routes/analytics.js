const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

router.get('/dashboard', protect, async (req, res) => {
  try {
    const categoryStats = await db.query('SELECT * FROM v_category_stats');
    const statusStats   = await db.query('SELECT status, COUNT(*) AS total FROM complaints GROUP BY status');
    const totals        = await db.query(`
      SELECT COUNT(*) AS total_complaints,
        SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) AS resolved,
        SUM(CASE WHEN status != 'Resolved' THEN 1 ELSE 0 END) AS active,
        SUM(CASE WHEN priority IN ('High','Critical') THEN 1 ELSE 0 END) AS high_priority,
        ROUND(AVG(rating)::numeric, 1) AS avg_rating
      FROM complaints`);
    const recent = await db.query(
      'SELECT ref_id, category, status, priority, created_at FROM complaints ORDER BY created_at DESC LIMIT 5'
    );
    res.json({ success:true, totals:totals.rows[0], categoryStats:categoryStats.rows, statusStats:statusStats.rows, recentComplaints:recent.rows });
  } catch (err) {
    res.status(500).json({ success:false, message:'Failed to load dashboard' });
  }
});

router.get('/trend', protect, restrictTo('Administrator','Councillor'), async (req, res) => {
  try {
    const monthly = await db.query(`
      SELECT TO_CHAR(created_at,'YYYY-MM') AS month, COUNT(*) AS total,
             SUM(CASE WHEN status='Resolved' THEN 1 ELSE 0 END) AS resolved
      FROM complaints GROUP BY month ORDER BY month DESC LIMIT 12`);
    res.json({ success:true, monthly:monthly.rows });
  } catch (err) {
    res.status(500).json({ success:false, message:'Failed to load trend data' });
  }
});

router.get('/reports', protect, restrictTo('Administrator','Councillor'), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, name, generated_by, total_complaints, resolved, active,
              critical, high, escalated, resolution_rate,
              category_breakdown, status_breakdown, priority_breakdown, created_at
       FROM reports ORDER BY created_at DESC LIMIT 50`
    );
    res.json({ success:true, reports:result.rows });
  } catch (err) {
    res.status(500).json({ success:false, message:'Failed to fetch reports' });
  }
});

router.post('/reports', protect, restrictTo('Administrator'), async (req, res) => {
  const {
    name,
    total_complaints=0, resolved=0, active=0,
    critical=0, high=0, escalated=0, resolution_rate=0,
    category_breakdown='[]', status_breakdown='[]', priority_breakdown='[]',
  } = req.body;

  if (!name || !name.trim())
    return res.status(400).json({ success:false, message:'Report name is required' });

  try {
    const result = await db.query(
      `INSERT INTO reports
         (name, generated_by, report_type, total_complaints, resolved, active,
          critical, high, escalated, resolution_rate,
          category_breakdown, status_breakdown, priority_breakdown)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [
        name.trim(),
        req.user.id,
        'custom',
        total_complaints, resolved, active,
        critical, high, escalated, resolution_rate,
        typeof category_breakdown==='string' ? category_breakdown : JSON.stringify(category_breakdown),
        typeof status_breakdown==='string'   ? status_breakdown   : JSON.stringify(status_breakdown),
        typeof priority_breakdown==='string' ? priority_breakdown : JSON.stringify(priority_breakdown),
      ]
    );
    res.status(201).json({ success:true, report:result.rows[0] });
  } catch (err) {
    console.error('POST /analytics/reports error:', err);
    res.status(500).json({ success:false, message:'Failed to save report' });
  }
});

router.delete('/reports/:id', protect, restrictTo('Administrator'), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ success:false, message:'Invalid ID' });
  try {
    const result = await db.query('DELETE FROM reports WHERE id=$1 RETURNING id', [id]);
    if (result.rowCount===0) return res.status(404).json({ success:false, message:'Report not found' });
    res.json({ success:true, message:'Report deleted' });
  } catch (err) {
    res.status(500).json({ success:false, message:'Failed to delete report' });
  }
});

module.exports = router;
