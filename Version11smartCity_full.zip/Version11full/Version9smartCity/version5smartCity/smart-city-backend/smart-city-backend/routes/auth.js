const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const db       = require('../config/db');
const { protect } = require('../middleware/auth');
const router   = express.Router();

// Valid roles that can be registered
const VALID_ROLES = ['Citizen', 'Technician', 'Administrator', 'Councillor'];

// Role → required email domain mapping (matches frontend)
const ROLE_EMAIL_DOMAINS = {
  Citizen:       '@citizen.co.za',
  Technician:    '@technician.gov.za',
  Administrator: '@admin.gov.za',
  Councillor:    '@councillor.gov.za',
};

const signToken = (user) =>
  jwt.sign(
    { id: user.id, email: user.email, role: user.role, full_name: user.full_name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );

// ─────────────────────────────────────────────────────────────────
// POST /api/auth/register
// ─────────────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { id_number, full_name, email, password, phone, role } = req.body;

    console.log('📝 Registration attempt:', { id_number, full_name, email, role });

    // ── Validate required fields ─────────────────────────────────
    if (!id_number || !full_name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required (id_number, full_name, email, password)',
      });
    }

    // ── Validate full name (no numbers) ──────────────────────────
    if (/[0-9]/.test(full_name)) {
      return res.status(400).json({
        success: false,
        message: 'Full name must not contain numbers',
      });
    }

    // ── Validate SA ID (exactly 13 digits) ───────────────────────
    if (!/^\d{13}$/.test(id_number.trim())) {
      return res.status(400).json({
        success: false,
        message: 'SA ID number must be exactly 13 digits',
      });
    }

    // ── Validate password strength ────────────────────────────────
    if (password.length < 8 || password.length > 15) {
      return res.status(400).json({
        success: false,
        message: 'Password must be 8–15 characters long',
      });
    }
    if ((password.match(/[A-Z]/g) || []).length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Password must contain at least 2 uppercase letters',
      });
    }
    if ((password.match(/[0-9]/g) || []).length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Password must contain at least 2 numbers',
      });
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      return res.status(400).json({
        success: false,
        message: 'Password must contain at least 1 special character',
      });
    }

    // ── Determine role ────────────────────────────────────────────
    const assignedRole = (role && VALID_ROLES.includes(role)) ? role : 'Citizen';

    // ── Validate email domain matches role ────────────────────────
    const requiredDomain = ROLE_EMAIL_DOMAINS[assignedRole];
    if (requiredDomain && !email.toLowerCase().endsWith(requiredDomain)) {
      return res.status(400).json({
        success: false,
        message: `Email for ${assignedRole} must end with ${requiredDomain}`,
      });
    }

    // ── Check if email or ID already exists ──────────────────────
    const { rows: existing } = await db.query(
      'SELECT id FROM users WHERE email = $1 OR id_number = $2',
      [email.toLowerCase(), id_number.trim()]
    );
    if (existing.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'Email address or ID number is already registered',
      });
    }

    // ── Hash password ─────────────────────────────────────────────
    const password_hash = await bcrypt.hash(password, 10);

    // ── Insert user ───────────────────────────────────────────────
    const { rows: inserted } = await db.query(
      `INSERT INTO users (id_number, full_name, email, password_hash, role, phone, is_active)
       VALUES ($1, $2, $3, $4, $5, $6, TRUE)
       RETURNING id`,
      [
        id_number.trim(),
        full_name.trim(),
        email.toLowerCase().trim(),
        password_hash,
        assignedRole,
        phone || null,
      ]
    );

    const userId = inserted[0].id;
    console.log(`✅ User registered: ID=${userId}, role=${assignedRole}, email=${email}`);

    // ── Build token ───────────────────────────────────────────────
    const newUser = {
      id:        userId,
      email:     email.toLowerCase().trim(),
      role:      assignedRole,
      full_name: full_name.trim(),
    };
    const token = signToken(newUser);

    res.status(201).json({
      success: true,
      message: `${assignedRole} account created successfully`,
      token,
      user: {
        id:        userId,
        id_number: id_number.trim(),
        full_name: full_name.trim(),
        email:     email.toLowerCase().trim(),
        role:      assignedRole,
        phone:     phone || null,
      },
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error during registration',
      error: err.message,
    });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/auth/login
// ─────────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password required' });
    }

    const { rows } = await db.query(
      'SELECT * FROM users WHERE email = $1',
      [email.toLowerCase().trim()]
    );
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const user = rows[0];

    if (!user.is_active) {
      return res.status(403).json({ success: false, message: 'Account is deactivated. Contact administrator.' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    console.log(`✅ Login: ${user.email} — role: ${user.role}`);

    const token = signToken(user);

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id:        user.id,
        id_number: user.id_number,
        full_name: user.full_name,
        email:     user.email,
        role:      user.role,
        phone:     user.phone,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Server error during login' });
  }
});

// ─────────────────────────────────────────────────────────────────
// GET /api/auth/me
// ─────────────────────────────────────────────────────────────────
router.get('/me', protect, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT id, id_number, full_name, email, role, phone, created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/auth/forgot-password
// Verifies the user exists by email + SA ID number, then returns a
// short-lived reset token (in a real deployment you'd email this;
// here we return it in the response for the frontend to use directly).
// ─────────────────────────────────────────────────────────────────
router.post('/forgot-password', async (req, res) => {
  try {
    const { email, id_number } = req.body;

    if (!email || !id_number) {
      return res.status(400).json({
        success: false,
        message: 'Email address and ID number are required',
      });
    }

    // Look up the user by both email AND id_number (extra security)
    const { rows } = await db.query(
      'SELECT id, email, full_name FROM users WHERE email = $1 AND id_number = $2 AND is_active = TRUE',
      [email.toLowerCase().trim(), id_number.trim()]
    );

    if (rows.length === 0) {
      // Return a generic message to avoid account enumeration
      return res.status(200).json({
        success: false,
        message: 'No active account found with that email and ID number combination.',
      });
    }

    const user = rows[0];

    // Generate a short-lived reset token (15 min)
    const resetToken = jwt.sign(
      { id: user.id, email: user.email, purpose: 'password-reset' },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );

    console.log(`🔑 Password reset token issued for: ${user.email}`);

    res.json({
      success: true,
      message: `Identity verified for ${user.full_name}. You may now set a new password.`,
      resetToken,
    });
  } catch (err) {
    console.error('Forgot-password error:', err);
    res.status(500).json({ success: false, message: 'Server error during password reset' });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /api/auth/reset-password
// Consumes the reset token and updates the password.
// ─────────────────────────────────────────────────────────────────
router.post('/reset-password', async (req, res) => {
  try {
    const { resetToken, newPassword } = req.body;

    if (!resetToken || !newPassword) {
      return res.status(400).json({ success: false, message: 'Reset token and new password are required' });
    }

    // Verify token
    let payload;
    try {
      payload = jwt.verify(resetToken, process.env.JWT_SECRET);
    } catch (_e) {
      return res.status(401).json({ success: false, message: 'Reset link has expired or is invalid. Please request a new one.' });
    }

    if (payload.purpose !== 'password-reset') {
      return res.status(401).json({ success: false, message: 'Invalid reset token' });
    }

    // Validate new password strength
    if (newPassword.length < 8 || newPassword.length > 15) {
      return res.status(400).json({ success: false, message: 'Password must be 8–15 characters long' });
    }
    if ((newPassword.match(/[A-Z]/g) || []).length < 2) {
      return res.status(400).json({ success: false, message: 'Password must contain at least 2 uppercase letters' });
    }
    if ((newPassword.match(/[0-9]/g) || []).length < 2) {
      return res.status(400).json({ success: false, message: 'Password must contain at least 2 numbers' });
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(newPassword)) {
      return res.status(400).json({ success: false, message: 'Password must contain at least 1 special character' });
    }

    const password_hash = await bcrypt.hash(newPassword, 10);

    await db.query(
      'UPDATE users SET password_hash = $1 WHERE id = $2',
      [password_hash, payload.id]
    );

    console.log(`✅ Password reset complete for user ID: ${payload.id}`);

    res.json({ success: true, message: 'Password updated successfully. You can now log in with your new password.' });
  } catch (err) {
    console.error('Reset-password error:', err);
    res.status(500).json({ success: false, message: 'Server error during password update' });
  }
});

module.exports = router;