const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

// ─────────────────────────────────────────────────────────────────
// PATCH /api/users/me — logged-in user updates their own email / phone
// ─────────────────────────────────────────────────────────────────
router.patch('/me', protect, async (req, res) => {
  try {
    const { email, phone } = req.body;
    const userId = req.user.id;

    // Role → required email domain (same mapping as registration)
    const ROLE_EMAIL_DOMAINS = {
      Citizen:       '@citizen.co.za',
      Technician:    '@technician.gov.za',
      Administrator: '@admin.gov.za',
      Councillor:    '@councillor.gov.za',
    };

    const fields = [];
    const vals   = [];
    let idx = 1;

    if (email !== undefined) {
      const newEmail = email.toLowerCase().trim();
      // Validate domain matches the user's current role
      const requiredDomain = ROLE_EMAIL_DOMAINS[req.user.role];
      if (requiredDomain && !newEmail.endsWith(requiredDomain)) {
        return res.status(400).json({
          success: false,
          message: `Your email must end with ${requiredDomain}`,
        });
      }
      // Check not already taken by another account
      const { rows: taken } = await db.query(
        'SELECT id FROM users WHERE email = $1 AND id <> $2',
        [newEmail, userId]
      );
      if (taken.length > 0) {
        return res.status(409).json({ success: false, message: 'That email is already in use by another account' });
      }
      fields.push(`email = $${idx++}`);
      vals.push(newEmail);
    }

    if (phone !== undefined) {
      fields.push(`phone = $${idx++}`);
      vals.push(phone || null);
    }

    if (!fields.length) {
      return res.status(400).json({ success: false, message: 'No fields to update' });
    }

    vals.push(userId);
    const { rows: updated } = await db.query(
      `UPDATE users SET ${fields.join(', ')} WHERE id = $${idx} RETURNING id, full_name, email, phone, role`,
      vals
    );

    console.log(`✅ User ${userId} updated own profile`);
    res.json({ success: true, message: 'Profile updated successfully', user: updated[0] });
  } catch (err) {
    console.error('Update-me error:', err);
    res.status(500).json({ success: false, message: 'Failed to update profile' });
  }
});

// GET all users (admin only)
router.get('/', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { role } = req.query;
    let sql = 'SELECT id, id_number, full_name, email, role, phone, is_active, created_at FROM users';
    const vals = [];
    if (role) { sql += ' WHERE role = $1'; vals.push(role); }
    const result = await db.query(sql, vals);
    res.json({ success: true, users: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch users' });
  }
});

// GET technicians with workload
router.get('/technicians', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT u.id, u.full_name, u.email, u.phone, COUNT(a.id) AS active_jobs
       FROM users u LEFT JOIN assignments a ON u.id = a.technician_id
       WHERE u.role = 'Technician' AND u.is_active = TRUE GROUP BY u.id ORDER BY active_jobs ASC`
    );
    res.json({ success: true, technicians: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch technicians' });
  }
});

// PATCH role only (legacy)
router.patch('/:id/role', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const { role } = req.body;
    await db.query('UPDATE users SET role = $1 WHERE id = $2', [role, req.params.id]);
    res.json({ success: true, message: `Role updated to ${role}` });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update role' });
  }
});

// PATCH /api/users/:id — edit a Technician or Councillor
router.patch('/:id', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const ALLOWED_ROLES = ['Technician', 'Councillor'];
    const { full_name, email, phone, role } = req.body;

    const { rows: existing } = await db.query(
      'SELECT role FROM users WHERE id = $1', [req.params.id]
    );
    if (!existing.length)
      return res.status(404).json({ success: false, message: 'User not found' });
    if (!ALLOWED_ROLES.includes(existing[0].role))
      return res.status(403).json({ success: false, message: 'Can only edit Technician or Councillor accounts' });

    const fields = [];
    const vals   = [];
    let idx = 1;
    if (full_name)           { fields.push(`full_name = $${idx++}`); vals.push(full_name.trim()); }
    if (email)               { fields.push(`email = $${idx++}`);     vals.push(email.toLowerCase().trim()); }
    if (phone !== undefined) { fields.push(`phone = $${idx++}`);     vals.push(phone || null); }
    if (role && ALLOWED_ROLES.includes(role)) { fields.push(`role = $${idx++}`); vals.push(role); }

    if (!fields.length)
      return res.status(400).json({ success: false, message: 'No fields to update' });

    vals.push(req.params.id);
    await db.query(`UPDATE users SET ${fields.join(', ')} WHERE id = $${idx}`, vals);
    res.json({ success: true, message: 'User updated successfully' });
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ success: false, message: 'Failed to update user' });
  }
});

// DELETE /api/users/:id — soft-delete a Technician or Councillor
router.delete('/:id', protect, restrictTo('Administrator'), async (req, res) => {
  try {
    const ALLOWED_ROLES = ['Technician', 'Councillor'];
    const { rows } = await db.query('SELECT role FROM users WHERE id = $1', [req.params.id]);
    if (!rows.length)
      return res.status(404).json({ success: false, message: 'User not found' });
    if (!ALLOWED_ROLES.includes(rows[0].role))
      return res.status(403).json({ success: false, message: 'Can only delete Technician or Councillor accounts' });

    await db.query('UPDATE users SET is_active = FALSE WHERE id = $1', [req.params.id]);
    res.json({ success: true, message: 'User deactivated successfully' });
  } catch (err) {
    console.error('Delete user error:', err);
    res.status(500).json({ success: false, message: 'Failed to delete user' });
  }
});

module.exports = router;
