const express = require('express');
const db      = require('../config/db');
const { protect, restrictTo } = require('../middleware/auth');
const router  = express.Router();

router.get('/', protect, restrictTo('Councillor', 'Administrator'), async (req, res) => {
  try {
    const { rows } = await db.query(`
      SELECT e.id AS escalation_id, e.complaint_id, e.councillor_id,
             e.escalation_type, e.decision, e.decision_notes,
             e.escalated_at, e.decided_at,
             c.ref_id, c.category, c.description, c.address,
             c.latitude, c.longitude, c.priority, c.status,
             u.full_name AS citizen_name
      FROM escalations e
      JOIN complaints c ON e.complaint_id = c.id
      JOIN users u ON c.citizen_id = u.id
      ORDER BY e.escalated_at DESC
    `);
    res.json({ success: true, escalations: rows });
  } catch (err) {
    console.error('GET /escalations error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch escalations', error: err.message });
  }
});

router.post('/', protect, restrictTo('Administrator', 'Citizen'), async (req, res) => {
  try {
    const { complaint_id, councillor_id } = req.body;

    if (!complaint_id || !councillor_id) {
      return res.status(400).json({ success: false, message: 'complaint_id and councillor_id are required' });
    }

    const existing = await db.query(
      "SELECT id FROM escalations WHERE complaint_id = $1 AND decision = 'Pending'",
      [complaint_id]
    );
    if (existing.rows.length > 0) {
      return res.json({ success: false, message: 'This complaint is already in the council queue' });
    }

    await db.query(
      `INSERT INTO escalations (complaint_id, councillor_id, escalated_by, escalation_type, decision, escalated_at)
       VALUES ($1, $2, $3, 'admin_escalation', 'Pending', NOW())`,
      [complaint_id, councillor_id, req.user.id]
    );

    await db.query(
      "UPDATE complaints SET status = 'Escalated' WHERE id = $1",
      [complaint_id]
    );

    return res.json({ success: true, message: 'Escalated successfully' });
  } catch (err) {
    console.error('Escalation error:', err);
    return res.status(500).json({ success: false, message: 'Database error during escalation' });
  }
});

router.post('/', protect, restrictTo('Administrator', 'Citizen'), async (req, res) => {
  try {
    const { complaint_id, councillor_id } = req.body;
    if (!complaint_id || !councillor_id) {
      return res.status(400).json({ success: false, message: 'complaint_id and councillor_id are required' });
    }
    const existing = await db.query(
      "SELECT id FROM escalations WHERE complaint_id = $1 AND decision = 'Pending'",
      [complaint_id]
    );
    if (existing.rows.length > 0) {
      return res.json({ success: false, message: 'This complaint is already in the council queue' });
    }
    await db.query(
      `INSERT INTO escalations (complaint_id, councillor_id, escalated_by, escalation_type, decision, escalated_at)
       VALUES ($1, $2, $3, 'admin_escalation', 'Pending', NOW())`,
      [complaint_id, councillor_id, req.user.id]
    );
    await db.query(
      "UPDATE complaints SET status = 'Escalated' WHERE id = $1",
      [complaint_id]
    );
    return res.json({ success: true, message: 'Escalated successfully' });
  } catch (err) {
    console.error('Escalation POST error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

router.patch('/:id/decision', protect, restrictTo('Councillor'), async (req, res) => {
  try {
    const { decision, decision_notes } = req.body;
    await db.query(
      'UPDATE escalations SET decision = $1, decision_notes = $2, decided_at = NOW() WHERE id = $3',
      [decision, decision_notes || null, req.params.id]
    );
    res.json({ success: true, message: 'Decision recorded' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to log decision' });
  }
});

module.exports = router;
