const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

pool.connect()
  .then(client => {
    console.log('✅  PostgreSQL connected — Supabase');
    client.release();
  })
  .catch(err => {
    console.error('❌  PostgreSQL failed:', err.message);
    process.exit(1);
  });

module.exports = pool;