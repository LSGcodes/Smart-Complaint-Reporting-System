require('dotenv').config();
console.log('DB_PASSWORD:', process.env.DB_PASSWORD);
console.log('DB_HOST:', process.env.DB_HOST);

const express = require('express');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');

const app = express();

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

app.use(cors({ origin: '*', credentials: false }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/api/health', (req, res) => res.json({ success: true, message: '🏙️ Smart City API is running' }));

const analyticsRouter = require('./routes/analytics');
app.use('/api/analytics', analyticsRouter);


app.use('/api/auth',          require('./routes/auth'));
app.use('/api/complaints',    require('./routes/complaints'));
app.use('/api/users',         require('./routes/users'));
app.use('/api/assignments',   require('./routes/assignments'));
try {
  const escalationsRouter = require('./routes/escalations');
  console.log('✅ escalations router loaded, routes:',
    escalationsRouter.stack?.map(r => `${Object.keys(r.route?.methods||{}).join(',').toUpperCase()} ${r.route?.path}`).join(' | ')
  );
  app.use('/api/escalations', escalationsRouter);
} catch(e) {
  console.error('❌ Failed to load escalations router:', e.message);
}
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/reports',       require('./routes/reports'));

app.use((req, res) => {
  console.log('❌ 404 — Method:', req.method, '| URL:', req.url, '| Path:', req.path);
  res.status(404).json({ success: false, message: 'Route not found' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════╗');
  console.log('║  🏙️  Smart City API running          ║');
  console.log(`║  http://localhost:${PORT}            ║`);
  console.log('╚══════════════════════════════════════╝');
});